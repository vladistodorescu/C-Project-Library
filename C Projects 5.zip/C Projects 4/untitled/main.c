#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAX_NAME_LEN 100
#define MAX_BOOKS 100
#define MAX_BOOK_NAME_LEN 100
#define MAX_CLIENTS 10
#define MAX_LOANS 50

typedef struct{
    char title[MAX_BOOK_NAME_LEN];
    char author[MAX_NAME_LEN];
    int copies_available;
}Book;

typedef struct{
    char name[MAX_NAME_LEN];
}Client;

typedef struct {
    char title[MAX_NAME_LEN];
    char author[MAX_NAME_LEN];
    char borrower[MAX_NAME_LEN];
}Loan;

void clear_input_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) { }
}

void load_books_from_file(Book books[], const char* filename){
    FILE *file = fopen(filename, "r");
    if (!file){
        printf("Failed to open file for reading! Please try again!");
        return;
    }

    int i = 0;
    while (!feof(file) && i < MAX_BOOKS){
        fscanf(file, "%99[^,], %99[^,], %d\n", books[i].title, books[i].author, &books[i].copies_available);
        i++;
    }

    if (ferror(file)) {
        perror("Error while reading file");
    } else {
        printf("Loaded %d books successfully.\n", i);
    }

    fclose(file);
}

void save_books_to_file(Book books[], const char* filename){
    FILE *file = fopen(filename, "w");
    if(!file){
        printf("Failed to open file for writing! Please try again!");
    }

    for (int i = 0; i < MAX_BOOKS; i++){
        if (books[i].title[0] != '\0'){
            fprintf(file, "%s, %s, %d\n", books[i].title, books[i].author, books[i].copies_available);
        }
    }

    fclose(file);
}

void load_loans_from_file(Loan loans[], const char* filename){
    FILE *file = fopen(filename, "r");
    if(!file) {
        printf("Failed to open file for reading! Please try again!");
        return;
    }

    int i = 0;
    while (!feof(file) && i < MAX_LOANS){
        fscanf(file, "%99[^,], %99[^,], %99[^\n]\n", loans[i].title, loans[i].author, loans[i].borrower);
        i++;
    }

    fclose(file);
}

void save_loans_to_file(Loan loans[], const char* filename){
    FILE *file = fopen(filename, "w");
    if(!file) {
        printf("Failed to open file for writing! Please try again!");
        return;
    }

    for (int i = 0; i < MAX_LOANS && loans[i].title[0] != '\0'; i++){
        fprintf(file, "%s, %s, %s\n", loans[i].title, loans[i].author, loans[i].borrower);
    }

    fclose(file);
}

void load_clients_from_file(Client clients[], const char* filename){
    FILE *file = fopen(filename, "r");
    if(!file) {
        printf("Failed to open file for reading! Please try again!");
        return;
    }

    int i = 0;
    while (!feof(file) && i < MAX_CLIENTS){
        fscanf(file, "%99[^\n]\n", clients[i].name);
        i++;
    }

    fclose(file);
}

void save_clients_to_file(Client clients[], const char* filename){
    FILE *file = fopen(filename, "w");
    if(!file) {
        printf("Failed to open file for writing! Please try again!");
        return;
    }

    for (int i = 0; i < MAX_CLIENTS && clients[i].name[0] != '\0'; i++){
        fprintf(file, "%s\n", clients[i].name);
    }

    fclose(file);
}

void donate_books(Book *books) {
    printf("Enter the title of the book you want to donate: \n");
    fflush(stdout);

    char book_title[MAX_NAME_LEN];
    if (fgets(book_title, MAX_NAME_LEN, stdin)) {
        book_title[strcspn(book_title, "\n")] = '\0';
    }

    printf("Enter the author of the book you want to donate: \n");
    fflush(stdout);

    char book_author[MAX_NAME_LEN];
    if (fgets(book_author, MAX_NAME_LEN, stdin)) {
        book_author[strcspn(book_author, "\n")] = '\0';
    }

    bool found_empty_slot = false;
    for (int i = 0; i < MAX_BOOKS; i++) {
        if (books[i].title[0] == '\0') {
            strncpy(books[i].title, book_title, MAX_BOOK_NAME_LEN);
            strncpy(books[i].author, book_author, MAX_NAME_LEN);
            books[i].copies_available = 1;
            printf("Thank you for your donation.\n");
            found_empty_slot = true;
            break;
        }
    }

    if (!found_empty_slot) {
        printf("Library is full, unable to accept more books.\n");
    }
}

void return_books(Book *books, Loan *loans){
    printf("Please enter your user credentials again: \n");
    fflush(stdout);

    char user_credentials[MAX_NAME_LEN];
    fgets(user_credentials, MAX_NAME_LEN, stdin);
    user_credentials[strcspn(user_credentials, "\n")] = 0;

    printf("Enter the title of the book you want to return: \n");
    fflush(stdout);

    char book_to_return[MAX_NAME_LEN];
    fgets(book_to_return, MAX_NAME_LEN, stdin);
    book_to_return[strcspn(book_to_return, "\n")] = 0;

    bool found = false;
    for (int i = 0; i < MAX_LOANS; i++){
        if (strcmp(loans[i].title, book_to_return) == 0 && strcmp(loans[i].borrower, user_credentials) == 0){
            found = true;

            for (int j = 0; j < MAX_BOOKS; j++) {
                if (strcmp(books[j].title, book_to_return) == 0) {
                    books[j].copies_available++;
                    break;
                }
            }

            for (int j = i; j < MAX_LOANS - 1; j++) {
                loans[j] = loans[j + 1];
            }
            memset(&loans[MAX_LOANS-1], 0, sizeof(loans[MAX_LOANS-1]));

            printf("You have successfully returned the book!\n");
            break;
        }
    }

    if (!found) {
        printf("Loan record not found.\n");
    }
}

void view_loans(Loan *loans){
    bool has_loans = false;

    for (int i = 0; i < MAX_LOANS; i++){
        if (loans[i].title[0] != '\0'){
            printf("The book %s, written by %s, was borrowed to %s.\n", loans[i].title, loans[i].author, loans[i].borrower);
            has_loans = true;
        }
    }

    if (!has_loans) {
        printf("There are no current loans.\n");
    }
}

void borrow_book(Book *books, Loan *loans){
    printf("Enter the title of the book you want to borrow:\n");
    fflush(stdout);

    char input_line[MAX_NAME_LEN];
    char book_to_borrow[MAX_NAME_LEN];

    fgets(input_line, sizeof(input_line), stdin);
    sscanf(input_line, "%[^\n]", book_to_borrow);

    for (int i = 0; i < MAX_BOOKS; i++) {
        if (strcmp(book_to_borrow, books[i].title) == 0) {
            if (books[i].copies_available == 0) {
                printf("Unfortunately, there are no more copies of this book available!\nPlease search for another book!\n");
                return;
            }
            printf("This book is available. Would you like to borrow it?\n(1) Yes\n(2) No\n");
            fflush(stdout);

            fgets(input_line, sizeof(input_line), stdin);
            int input;
            sscanf(input_line, "%d", &input);

            while (input != 1 && input != 2) {
                printf("Wrong input, try again:\n");
                fflush(stdout);
                fgets(input_line, sizeof(input_line), stdin);
                sscanf(input_line, "%d", &input);
            }

            if (input == 1) {
                books[i].copies_available -= 1;
                printf("Please enter your user credentials again: \n");
                fflush(stdout);

                fgets(input_line, sizeof(input_line), stdin);
                char user_credentials[MAX_NAME_LEN];
                sscanf(input_line, "%[^\n]", user_credentials);

                for (int j = 0; j < MAX_LOANS; j++) {
                    if (loans[j].title[0] == '\0') {
                        strncpy(loans[j].title, book_to_borrow, MAX_NAME_LEN);
                        strncpy(loans[j].author, books[i].author, MAX_NAME_LEN);
                        strncpy(loans[j].borrower, user_credentials, MAX_NAME_LEN);
                        printf("You have successfully borrowed the book.\n");
                        return;
                    }
                }
            } else if (input == 2) {
                printf("No problem. Let us know if there's another book you'd like to borrow.\n");
                return;
            }
        }
    }

    printf("The book you requested is not found in our library.\n");
}

void show_library(Book *books){
    printf("----------Library----------\n");
    for (int i = 0; i < MAX_BOOKS; i++){
        if (books[i].copies_available > 0){
            printf("%d. %s by %s\n", i + 1, books[i].title, books[i].author);
        }
    }
}

void search_books(Book *books) {
    printf("(1) Search books by title\n(2) Search books by author\n");
    int menu_option;
    scanf("%d", &menu_option);
    getchar();

    if (menu_option == 1) {
        printf("Enter the title of the book:\n");
        char book_title[MAX_NAME_LEN];
        fgets(book_title, MAX_NAME_LEN, stdin);
        book_title[strcspn(book_title, "\n")] = 0;

        bool book_found = false;
        for (int i = 0; i < MAX_BOOKS; i++) {
            if (strcmp(book_title, books[i].title) == 0) {
                printf("Book: %s\nAuthor: %s\nCopies available: %d\n", books[i].title, books[i].author,
                       books[i].copies_available);
                book_found = true;
                break;
            }
        }

        if (book_found == false) {
            printf("Book was not found, please try again!\n");
            search_books(books);
        }
    }

    if (menu_option == 2) {
        printf("Enter the Author of the book: ");
        char book_author[MAX_NAME_LEN];
        fgets(book_author, MAX_NAME_LEN, stdin);
        book_author[strcspn(book_author, "\n")] = 0;

        bool author_found = false;
        int nr_books = 0;
        for (int i = 0; i < MAX_BOOKS; i++) {
            if (strcmp(book_author, books[i].author) == 0) {
                if (nr_books == 0) {
                    printf("There are the following books from this author: \n");
                    nr_books += 1;
                    printf("%d. %s\n",nr_books, books[i].title);
                    author_found = true;
                } else {
                    nr_books += 1;
                    printf("%d. %s\n", nr_books, books[i].title);

                }
            }
        }

        if (author_found == false) {
            printf("This author has not been found. Please try again.\n");
            search_books(books);
        }
    }
}

int main(){

    Book books[MAX_BOOKS] = {0};
    Loan loans[MAX_LOANS] = {0};
    Client clients[MAX_CLIENTS] = {0};

    load_books_from_file(books, "/Users/vladistodorescu/C Projects 4/untitled/Books.txt");
    load_loans_from_file(loans, "/Users/vladistodorescu/C Projects 4/untitled/Loans.txt");
    load_clients_from_file(clients, "/Users/vladistodorescu/C Projects 4/untitled/Clients.txt");

    printf("\n----------Hello! Welcome to the Library Management System!----------\n");
    printf("Log in or create an account:\n");
    printf("(1) Log in\n");
    printf("(2) Create an account\n");

    int first_input;
    scanf("%d", &first_input);
    clear_input_buffer();

    while (first_input != 1 && first_input != 2) {
        printf("Invalid option. Please select 1 or 2:\n");
        printf("(1) Log in\n");
        printf("(2) Create an account\n");
        scanf("%d", &first_input);
        clear_input_buffer();
    }

    if (first_input == 2) {
        char account_name[MAX_NAME_LEN];
        printf("Enter your name: [First Name] [Last Name]\n");
        fgets(account_name, MAX_NAME_LEN, stdin);
        account_name[strcspn(account_name, "\n")] = 0;

        int i = 0;
        for (; i < MAX_CLIENTS && clients[i].name[0] != '\0'; i++);
        if (i < MAX_CLIENTS) {
            strncpy(clients[i].name, account_name, MAX_NAME_LEN);
            printf("Your account has been created!\n");
        } else {
            printf("Max clients reached. Cannot create new account.\n");
        }
    }

    bool login = false;
    int user_id;

    while (!login) {
        char login_input[MAX_NAME_LEN];
        printf("Login: [First Name] [Last Name]\n");
        fgets(login_input, MAX_NAME_LEN, stdin);
        login_input[strcspn(login_input, "\n")] = 0;
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (strcmp(login_input, clients[i].name) == 0) {
                printf("Login successful!\n");
                login = true;
                user_id = i;
                break;
            }
        }
        if (!login) {
            printf("Login failed. Please try again.\n");
        }
    }

    char user[MAX_NAME_LEN];
    strcpy(user, clients[user_id].name);
    bool exit_app = false;

    while (!exit_app) {
        int menu_option;
        printf("\n----------Welcome to the Menu!----------\n[1] Borrow Books\n[2] Return Books\n[3] Donate Books\n[4] View Loans\n[5] Search Books\n[6] Show Library\n[7] Exit\n");
        scanf("%d", &menu_option);
        clear_input_buffer();
        switch (menu_option) {
            case 1: borrow_book(books, loans); break;
            case 2: return_books(books, loans); break;
            case 3: donate_books(books); break;
            case 4: view_loans(loans); break;
            case 5: search_books(books); break;
            case 6: show_library(books); break;
            case 7: exit_app = true; break;
            default: printf("Invalid option. Please select a valid number from the menu.\n"); break;
        }
    }

    save_books_to_file(books, "/Users/vladistodorescu/C Projects 4/untitled/Books.txt");
    save_loans_to_file(loans, "/Users/vladistodorescu/C Projects 4/untitled/Loans.txt");
    save_clients_to_file(clients, "/Users/vladistodorescu/C Projects 4/untitled/Clients.txt");

    return 0;
}
